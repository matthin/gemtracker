#include "RouteManager.h"

int main() {
    GemTracker::RouteManager routeManager;
}

