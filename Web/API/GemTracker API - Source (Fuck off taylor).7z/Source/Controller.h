#pragma once

namespace GemTracker {

class Controller {
public:
};

}

